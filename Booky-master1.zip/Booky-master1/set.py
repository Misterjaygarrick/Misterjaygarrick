from cx_Freeze import setup, Executable

setup(
    name = "Contact book",
    version = "1.0",
    description = "Yon lojisyel pouw jere kontak ou ye",
    executables = [Executable("C:\Users\ROOTCHY\Downloads\Booky-master\Booky-master1")],


    )